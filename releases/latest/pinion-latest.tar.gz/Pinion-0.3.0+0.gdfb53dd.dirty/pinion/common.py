import os

PKG_BASE = os.path.dirname(__file__)
RESOURCES = os.path.join(PKG_BASE, "resources")
