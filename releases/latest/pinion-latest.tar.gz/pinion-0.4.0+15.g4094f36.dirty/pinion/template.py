import os
import re
from ruamel.yaml import YAML
from ruamel.yaml.comments import Comment, CommentedSeq, CommentedMap

yaml=YAML()
yaml.default_flow_style=False
yaml.width=80
yaml.indent=4

def collectPins(scene, footprint):
    pins = CommentedMap()
    for i, name in enumerate(footprint.pads):
        pad = scene.pads[(footprint.reference, name)]
        p = CommentedMap()
        p.insert(0, "name", pad.net or "")
        p.insert(1, "description", "")
        p.insert(2, "groups", [])
        pins.insert(i, name, p)
    return pins

def collectComponents(board, components=None):
    """
    Collect components template from the board. Include only footprints in
    components if specified
    """
    d = CommentedMap()
    footprints = [f for f in board.components.values()
        if components is None or len(components) == 0 or any([re.match(c, f.reference) for c in components])]
    footprints.sort(key=lambda f: f.reference)
    for i, f in enumerate(footprints):
        description = CommentedMap()
        description.insert(0, "description", f.value, "Arbitrary comment")
        description.insert(1, "groups", [], "Specify component groups")
        description.insert(2, "pins", collectPins(board, f))
        description.insert(3, "highlight", False, "Make the component active")
        description.insert(4, "highlightBoth", any(
            board.pads[(f.reference, name)].through_hole for name in f.pads))
        d.insert(i, f.reference, description)
    return d

def generateTemplate(board, output, components):
    """
    Given a board and output file, generate template. Template includes all
    components and all pins.
    """
    d = CommentedMap()
    name = os.path.basename(board.source_path)
    name = os.path.splitext(name)[0]
    d.insert(0, "name", name, "Put the name of diagram here")
    d.insert(1, "description", "Example diagram", "Put a short description of the diagram here")
    d.insert(2, "components", collectComponents(board, components))

    yaml.dump(data=d, stream=output)
