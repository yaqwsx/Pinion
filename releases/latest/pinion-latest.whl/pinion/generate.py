from pathlib import Path
import json
import base64

from typing import Tuple, Callable, Dict, Optional

from pcbdraw.plot import (PcbPlotter, PlotComponents, PlotSubstrate,
                          load_remapping, mm_to_internal)
from pcbdraw import convert

from pinion import __version__

def padOutline(pad):
    """
    Given a pad return list of points forming a polygon for the pad shape
    """
    return pad.outline

def serializeEdaRect(rect):
    return {
        "tl": (rect.x, rect.y),
        "br": (rect.x + rect.width, rect.y + rect.height)
    }

def intervalIntersection(a, b):
    """
    Compute interval intersection, return it as tuple or None
    """
    a = (min(a[0], a[1]), max(a[0], a[1]))
    b = (min(b[0], b[1]), max(b[0], b[1]))
    if b[0] > a[0]:
        a, b = b, a
    # The intervals are sorted from left to right
    if b[0] > a[1] or b[1] < a[0]:
        return None
    return b[0], min(a[1], b[1])

def overlappingRectComparator(a, b):
    """
    Compare two serialized rects based on which one contains more of the other
    one. Since such an ordering is incomplete, the function returns the
    following:
    - -1 if a is below b
    - 1 if b is below a
    - 0 if the order doesn't matter
    """
    xIntersection = intervalIntersection(
        (a["tl"][0], a["br"][0]),
        (b["tl"][0], b["br"][0]))
    yIntersection = intervalIntersection(
        (a["tl"][1], a["br"][1]),
        (b["tl"][1], b["br"][1]))
    if xIntersection is None or yIntersection is None:
        return 0
    aArea = (a["br"][0] - a["tl"][0]) * (a["br"][1] - a["tl"][1])
    bArea = (b["br"][0] - b["tl"][0]) * (b["br"][1] - b["tl"][1])
    iArea = (xIntersection[1] - xIntersection[0]) * (yIntersection[1] - yIntersection[0])
    if iArea / aArea > iArea / bArea:
        return -1
    return 1

def sortByRectangles(items):
    """
    Implementation of insert sort on partial ordering for overlapping
    rectangles.
    """
    for i in range(1, len(items)):
        for j in reversed(range(i)):
            cmp = overlappingRectComparator(items[j]["bbox"], items[j+1]["bbox"])
            if cmp == 1:
                break
            items[j], items[j + 1] = items[j + 1], items[j]
    return items


def pinDefinition(spec, pad, footprint):
    """
    Given a pin specification and pad, construct description
    """
    return {
        "shape": padOutline(pad),
        "bbox": serializeEdaRect(pad.bbox),
        "pos": list(pad.position),
        "front": "F.Cu" in pad.layers,
        "back": "B.Cu" in pad.layers,
        "name": spec["name"],
        "description": spec.get("description", ""),
        "alias": spec.get("alias", False),
        "groups": getGroup(spec)
    }

def pinsDefinition(spec, footprint, board):
    """
    Given a pins definition and a footprint, construct description
    """
    if spec is None:
        return []
    return [
        pinDefinition(spec[name], board.pads[(footprint.reference, name)], footprint)
        for name in footprint.pads
        if name in spec.keys()
    ]

def componentsDefinition(spec, board):
    """
    Given a specification, construct component description
    """
    defs = []
    for ref, s in spec.items():
        footprint = board.components[ref]
        highlightBoth = s.get("highlightBoth", False)
        defs.append({
            "ref": ref,
            "description": s["description"],
            "front": highlightBoth or footprint.side == "front",
            "back": highlightBoth or footprint.side == "back",
            "highlight": s.get("highlight", False),
            "bbox": serializeEdaRect(footprint.bbox),
            "groups": getGroup(s),
            "pins": pinsDefinition(s.get("pins", None), footprint, board)
        })
    # Sort the components so overlapping components are placed on top of each
    # other
    sortByRectangles(defs)
    return defs

def generateImage(boardfilename, outputfilename, dpi, pcbdrawArgs, back):
    """
    Generate board image for the diagram. Returns bounding box (top let, bottom
    right) active areas of the images in KiCAD native units.
    """

    plotter = PcbPlotter(boardfilename)
    plotter.setup_arbitrary_data_path(".")
    plotter.setup_env_data_path()
    plotter.setup_builtin_data_path()
    plotter.setup_global_data_path()

    plotter.yield_warning = print


    if pcbdrawArgs["libs"] is not None:
        plotter.libs = pcbdrawArgs["libs"]
    plotter.render_back = back
    plotter.svg_precision = 5
    if pcbdrawArgs["style"] is not None:
        plotter.resolve_style(pcbdrawArgs["style"])

    # Prepare components
    remapping = load_remapping(pcbdrawArgs["remap"])
    def remapping_fun(ref: str, lib: str, name: str) -> Tuple[str, str]:
        if ref in remapping:
            remapped_lib, remapped_name = remapping[ref]
            if name.endswith('.back'):
                return remapped_lib, remapped_name + '.back'
            else:
                return remapped_lib, remapped_name
        return lib, name

    plot_components = PlotComponents(remapping=remapping_fun)
    if pcbdrawArgs["filter"] is not None:
        filter_set = set(pcbdrawArgs["filter"])
        def filter_fun(ref: str) -> bool:
            return ref in filter_set
        plot_components.filter = filter_fun

    plotter.plot_plan = [
        PlotSubstrate(drill_holes=True, outline_width=mm_to_internal(0.2)),
        plot_components]

    image = plotter.plot()

    convert.save(image, outputfilename, dpi)

    tlx, tly, w, h = map(float, image.getroot().attrib["viewBox"].split())
    return {
        "tl": (tlx, tly),
        "br": (tlx + w, tly + h)
    }

def collectGroups(components):
    groups = set()
    for c in components.values():
        groups.update(getGroup(c))
        pins = c.get("pins", None)
        if pins is not None:
            for p in pins.values():
                groups.update(getGroup(p))
    groups = list(groups)
    groups.sort()
    return { g: [] for g in groups }

def validateGroupStructure(struct):
    """
    Validate structure and transform it into a canonical form
    """
    newStruct = {}
    if not isinstance(struct, dict):
        raise RuntimeError(f"{struct} is not a dictionary")
    for key, value in struct.items():
        if not isinstance(key, str):
            raise RuntimeError(f"{key} is not a string")
        if value is None:
            newStruct[key] = {}
            continue
        if isinstance(value, dict):
            newStruct[key] = validateGroupStructure(value)
        if isinstance(value, list):
            newStruct[key] = { v: {} for v in value }
    return newStruct

def groupStructure(structure, components):
    """
    If a group structure is provided, validate it and return it. If not, build a
    flat structure from components.
    """
    if structure is None:
        return collectGroups(components)
    return validateGroupStructure(structure)

def getGroup(spec):
    g = spec.get("groups", [])
    if g is None:
        return []
    return g

def packPinion(outputdir):
    from pinion.get import get
    with open(outputdir / "pinion.js", "w") as f:
        get("js", f)
    with open(outputdir / "pinion.css", "w") as f:
        get("css", f)
    with open(outputdir / "template.html", "w") as f:
        get("template", f)

def embedResource(filename: Path, mimeType: str) -> str:
    with open(filename, "rb") as f:
        payload = base64.b64encode(f.read()).decode("ascii")
    return f"data:{mimeType};base64,{payload}"

def scriptText(text: str) -> str:
    return text.replace("</", "<\\/")

def embeddedSpecification(outputdir: Path, specification: any):
    embedded = json.loads(json.dumps(specification))
    for side in ["front", "back"]:
        if side in embedded:
            embedded[side]["file"] = embedResource(outputdir / embedded[side]["file"], "image/png")
    return embedded

def embedPinion(outputdir: Path, specification: any):
    from pinion.get import get
    import io

    js = io.StringIO()
    css = io.StringIO()
    get("js", js)
    get("css", css)

    spec = scriptText(json.dumps(embeddedSpecification(outputdir, specification)))
    js = scriptText(js.getvalue())
    css = css.getvalue()

    with open(outputdir / "index.html", "w") as f:
        f.write(f"""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <style>
{css}
    </style>
    <title>Pinion diagram</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div style="max-width: 1400px; margin: 0 auto;">
      <div id="root"></div>
    </div>

    <script>
{js}
    </script>
    <script type="application/json" id="pinion-spec">{spec}</script>
    <script>
        const pinionWidget = pinion.setup(document.getElementById("root"), {{
            source: "",
            specification: JSON.parse(document.getElementById("pinion-spec").textContent)
        }});
        pinion.setupHashHandler(pinionWidget);
    </script>
  </body>
</html>
""")

ImageGenerator = Callable[[object, Path, Tuple[str, ...]], Dict[str, Dict[str, Tuple[int, int]]]]

def generateDrawnImages(board: object, outputdir: Path, dpi: int, pcbdrawArgs: any,
                        sides: Tuple[str, ...]) -> Dict[str, Dict[str, Tuple[int, int]]]:
    result = {}
    if "front" in sides:
        result["front"] = generateImage(board.source_path, outputdir / "front.png",
            dpi, pcbdrawArgs, False)
    if "back" in sides:
        result["back"] = generateImage(board.source_path, outputdir / "back.png",
            dpi, pcbdrawArgs, True)
    return result

def boardAreaRect(board: object):
    """
    Get the board bounding box in mm, suitable for the pinout spec.
    """
    return serializeEdaRect(board.bounds)

def generateRenderedImages(board: object, outputdir: Path,
                     orthographic: bool, raytraced: bool,
                     baseResolution: Tuple[int, int], sides: Tuple[str, ...]):
    from pcbdraw.renderer import RenderAction, renderBoard, Side

    result = {}
    if "front" in sides:
        frontImage = renderBoard(board.source_path, RenderAction(
            side=Side.FRONT,
            raytraced=raytraced,
            orthographic=orthographic,
            transparent=True,
            width=baseResolution[0],
            height=baseResolution[1],
            padding=0,
        ))
        frontImage.save(outputdir / "front.png")
        result["front"] = boardAreaRect(board)

    if "back" in sides:
        backImage = renderBoard(board.source_path, RenderAction(
            side=Side.BACK,
            raytraced=raytraced,
            orthographic=orthographic,
            transparent=True,
            width=baseResolution[0],
            height=baseResolution[1],
            padding=0,
        ))
        backImage.save(outputdir / "back.png")
        bArea = boardAreaRect(board)
        result["back"] = {
            "tl": (-(bArea["br"][0]), bArea["tl"][1]),
            "br": (-(bArea["tl"][0]), bArea["br"][1])
        }
    return result


def generate(board: object, specification: any, outputdir, pack: bool,
             embed: bool, sides: Tuple[str, ...],
             imageGenerator: ImageGenerator):
    """
    Generate board pinout diagram
    """
    outputdir = Path(outputdir)
    outputdir.mkdir(parents=True, exist_ok=True)

    imageSources = imageGenerator(board, outputdir, sides)

    specification = {
        "pinionVersion": __version__,
        "name": specification["name"],
        "description": specification["description"],
        "components": componentsDefinition(specification["components"], board),
        "groups": groupStructure(specification.get("groups", None), specification["components"])
    }
    if "front" in imageSources:
        specification["front"] = {
            "file": "front.png",
            "area": imageSources["front"]
        }
    if "back" in imageSources:
        specification["back"] = {
            "file": "back.png",
            "area": imageSources["back"]
        }

    with open(outputdir / "spec.json", "w") as f:
        f.write(json.dumps(specification, indent=4))

    if pack:
        packPinion(outputdir)
    if embed:
        embedPinion(outputdir, specification)
