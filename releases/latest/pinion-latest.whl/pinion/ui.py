import click
import csv
import io
import functools
from pathlib import Path
from typing import Dict, Tuple
from pinion import __version__
from pinion.generate import generateDrawnImages

def splitStr(delimiter, escapeChar, s):
    """
    Splits s based on delimiter that can be escaped via escapeChar
    """
    # Let's use csv reader to implement this
    reader = csv.reader(io.StringIO(s), delimiter=delimiter, escapechar=escapeChar)
    # Unpack first line
    for x in reader:
        return x


class CliList(click.ParamType):
    """
    A CLI argument type for specifying comma separated list of strings
    """
    name = "list"

    def __init__(self, separator=",", escape="\\", *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.separator = separator
        self.escape = escape

    def convert(self, value, param, ctx):
        if len(value.strip()) == 0:
            self.fail(f"{value} is not a valid argument specification",
                param, ctx)
        return list(splitStr(self.separator, self.escape, value))


def selectedSides(side):
    if side == "both":
        return ("front", "back")
    return (side,)


def cwdProjectName(cwd=Path(".")):
    return Path(cwd).resolve().name


def selectDefaultPath(preferred, candidates, kind, option):
    if preferred.exists():
        return preferred

    candidates = sorted(candidates)
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) == 0:
        raise click.ClickException(
            f"Cannot infer {kind}; pass {option} explicitly.")
    raise click.ClickException(
        f"Cannot infer {kind}; multiple candidates found: "
        f"{', '.join(str(x) for x in candidates)}. Pass {option} explicitly.")


def defaultBoardPath(cwd=Path(".")):
    cwd = Path(cwd)
    preferred = cwd / f"{cwdProjectName(cwd)}.kicad_pcb"
    return selectDefaultPath(
        preferred,
        cwd.glob("*.kicad_pcb"),
        "board file",
        "--board")


def defaultSpecificationPath(cwd=Path(".")):
    cwd = Path(cwd)
    projectName = cwdProjectName(cwd)
    preferredYaml = cwd / f"{projectName}_pinion.yaml"
    if preferredYaml.exists():
        return preferredYaml

    preferredYml = cwd / f"{projectName}_pinion.yml"
    return selectDefaultPath(
        preferredYml,
        list(cwd.glob("*_pinion.yaml")) + list(cwd.glob("*_pinion.yml")),
        "specification file",
        "--specification")


def defaultTemplateOutputPath(cwd=Path(".")):
    cwd = Path(cwd)
    return cwd / f"{cwdProjectName(cwd)}_pinion.yaml"


def resolveBoard(ctx, param, value):
    if value is not None:
        return value
    return str(defaultBoardPath())


def resolveSpecification(ctx, param, value):
    if value is not None:
        return value
    return str(defaultSpecificationPath())


def resolveTemplateOutput(output):
    if output is not None:
        return output

    output = defaultTemplateOutputPath()
    if output.exists():
        raise click.ClickException(
            f"Refusing to overwrite inferred template output {output}. "
            "Pass --output explicitly to overwrite it.")
    return str(output)


@click.command("template")
@click.option("-b", "--board",
    type=click.Path(file_okay=True, dir_okay=False, exists=True),
    callback=resolveBoard,
    help="Source KiCAD board (*.kicad_pcb). Defaults to the project-named board or the only board in the current directory.")
@click.option("-o", "--output", type=click.Path(dir_okay=False), default=None,
    help="Filepath or stdout (when '-' specified) for the resulting template. Defaults to <project>_pinion.yaml.")
@click.option("-c", "--components", type=str, default=None, multiple=True,
    help="Include only components mathing regex in the template")
def template(board, output, components):
    """
    Output a template for pinout specification based on specified board
    """
    # Note that we import inside functions as pcbnew import takes ~1 to load
    # which makes the UI laggy
    from pinion.template import generateTemplate
    import pcbnew

    outputPath = resolveTemplateOutput(output)
    pcb = pcbnew.LoadBoard(board)
    with click.open_file(outputPath, "w") as outputFile:
        generateTemplate(pcb, outputFile, components)


def generateCommandArgs(func):
    @click.argument("outputdir", type=click.Path(file_okay=False, dir_okay=True))
    @click.option("-b", "--board",
    type=click.Path(file_okay=True, dir_okay=False, exists=True),
    callback=resolveBoard,
    help="Source KiCAD board (*.kicad_pcb). Defaults to the project-named board or the only board in the current directory.")
    @click.option("-s", "--specification",
    type=click.Path(file_okay=True, dir_okay=False, exists=True),
    callback=resolveSpecification,
    help="YAML specification of the pinout. Defaults to <project>_pinion.yaml or the only *_pinion YAML file.")
    @click.option("--pack/--no-pack", default=True,
    help="Pack pinion-widget with the source")
    @click.option("--embed/--no-embed", default=False,
    help="Generate a standalone index.html with all resources embedded")
    @click.option("--side", type=click.Choice(["front", "back", "both"]), default="both",
    help="Which board side to include in the diagram")

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


@click.command("plotted")
@generateCommandArgs
@click.option("--dpi", type=int, default=300,
    help="DPI of the generated board image")
@click.option("--style", help="PcbDraw style specification")
@click.option("--libs", type=CliList(),
    help="PcbDraw library specification")
@click.option("--remap", help="PcbDraw footprint remapping specification")
@click.option("--filter", help="PcbDraw filter specification")
def generatePlotted(board, specification, outputdir, dpi, pack, embed, side, style, libs, remap, filter):
    """
    Generate a pinout diagram with stylized image of the board
    """
    # Note that we import inside functions as pcbnew import takes ~1 to load
    # which makes the UI laggy
    from pinion.generate import generate, generateDrawnImages
    from ruamel.yaml import YAML
    import pcbnew

    yaml=YAML(typ='safe')

    def generateImages(board: pcbnew.BOARD, outputdir: Path, sides) -> Dict[str, Dict[str, Tuple[int, int]]]:
        return generateDrawnImages(board, outputdir, dpi, {
                 "style": style,
                 "libs": libs,
                 "remap": remap,
                 "filter": filter
             }, sides)

    with click.open_file(specification, "r") as specificationFile:
        generate(specification=yaml.load(specificationFile),
                 board=pcbnew.LoadBoard(board),
                 outputdir=outputdir,
                 pack=pack,
                 embed=embed,
                 sides=selectedSides(side),
                 imageGenerator=generateImages)

@click.command("rendered")
@generateCommandArgs
@click.option("--renderer", type=click.Choice(["raytrace", "normal"]), default="raytrace",
    help="Specify what renderer to use")
@click.option("--projection", type=click.Choice(["orthographic", "perspective"]), default="orthographic",
    help="Specify projection")
@click.option("--no-components", is_flag=True, default=False,
    help="Disable component rendering")
def generateRendered(board, specification, pack, outputdir, renderer,
                     embed, side, projection, no_components):
    """
    Generate a pinout diagram with 3D rendered image of the board
    """
    # Note that we import inside functions as pcbnew import takes ~1 to load
    # which makes the UI laggy
    from pinion.generate import generate, generateRenderedImages
    from ruamel.yaml import YAML
    import pcbnew

    yaml=YAML(typ='safe')

    def generateImages(board: pcbnew.BOARD, outputdir: Path, sides) -> Dict[str, Dict[str, Tuple[int, int]]]:
        return generateRenderedImages(board, outputdir,
            componets=(not no_components),
            orthographic=(projection == "orthographic"),
            raytraced=(renderer == "raytrace"),
            baseResolution=(3000, 3000),
            sides=sides)

    with click.open_file(specification, "r") as specificationFile:
        generate(specification=yaml.load(specificationFile),
                 board=pcbnew.LoadBoard(board),
                 outputdir=outputdir,
                 pack=pack,
                 embed=embed,
                 sides=selectedSides(side),
                 imageGenerator=generateImages)


@click.group()
def generate():
    """
    Generate the diagram using one of the following strategies
    """
    pass

generate.add_command(generatePlotted)
generate.add_command(generateRendered)

@click.command("get")
@click.argument("what", type=str)
@click.argument("output", type=click.File("w"))
def get(what, output):
    """
    Get Pinion resource files - e.g., template, pinion-widget javascript or
    pinion-widget styles.

    Available options: js css template
    """
    import pinion.get
    return pinion.get.get(what, output)

@click.command("serve")
@click.option("--directory", "-d", type=click.Path(dir_okay=True, file_okay=False),
    default="./", help="Directory to serve")
@click.option("--port", "-p", type=int, default=3333,
    help="Port on which to run a webserver")
@click.option("--browser", "-b", is_flag=True,
    help="Automatically open web browser")
def serve(directory, port, browser):
    """
    Serve pinion digram generated with the '--pack' option.
    """
    from pinion.serve import serve
    return serve(directory, port, browser)

@click.group()
@click.version_option(__version__)
def cli():
    """
    Generate beautiful pinout digrams of your PCBs for web.
    """
    pass

cli.add_command(template)
cli.add_command(generate)
cli.add_command(get)
cli.add_command(serve)

if __name__ == "__main__":
    cli()
